import React from 'react'
import logo from './logo.jpeg'
import './Logo.css'

function Logo() {
    return (
<div className="mainlogo">
<img className='logoimage' src={logo} alt="logo" />
</div>
    )
}

export default Logo
