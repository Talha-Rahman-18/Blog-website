import React from 'react'
import Postform from '../components/postform/Postform'
function AddPost() {
    return (
        
        <div className="addpost" style={{
            height:"max-content",width:"100vw",margin:"0",padding:"0"
        }}>
            <Postform />
        </div>
    )
}

export default AddPost
