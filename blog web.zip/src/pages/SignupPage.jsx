import React from 'react'
import Signup from '../components/signup/Signup'

function SignupPage() {
    return (
        <div className="signpage" style={{height:"100%",width:"100vw"}}>
<Signup />
        </div>
    )
}

export default SignupPage
